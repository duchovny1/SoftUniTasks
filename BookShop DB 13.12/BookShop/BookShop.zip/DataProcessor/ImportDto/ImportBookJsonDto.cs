﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ImportDto
{
    public class ImportBookJsonDto
    {
        public string Id { get; set; }
    }
}
